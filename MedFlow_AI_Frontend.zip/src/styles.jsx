/* Design system for the MedFlow demo. Extracted verbatim from the original
   MedFlowApp.jsx, plus additions for the AI-contract views. */

export function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');

      .mf-app {
        --paper: #F4F6F5; --paper-raised: #FFFFFF; --ink: #14213D; --ink-soft: #59667A;
        --blue: #1D5C7A; --blue-dark: #164A63; --blue-soft: #E4EEF2;
        --sage: #4F7C6C; --sage-soft: #E7EFEC; --amber: #A8672E; --amber-soft: #F6ECDF;
        --clay: #A8433B; --clay-soft: #F5E7E5; --line: #DCE1E4; --line-soft: #E8ECEE;
        --r-xs: 5px; --r-sm: 7px; --r-md: 10px; --r-lg: 14px;
        --shadow-xs: 0 1px 2px rgba(20,33,61,0.05);
        --shadow-sm: 0 1px 3px rgba(20,33,61,0.06), 0 1px 2px rgba(20,33,61,0.04);
        --shadow-md: 0 4px 14px rgba(20,33,61,0.08), 0 1px 3px rgba(20,33,61,0.04);
        --shadow-lg: 0 12px 34px rgba(20,33,61,0.13);
        --ring: 0 0 0 3px rgba(29,92,122,0.22);
        --ease: cubic-bezier(0.32, 0.72, 0, 1);
        font-family: 'IBM Plex Sans', system-ui, sans-serif;
        background: var(--paper); color: var(--ink); min-height: 100vh;
        -webkit-font-smoothing: antialiased; text-rendering: optimizeLegibility;
      }
      .mf-app *, .mf-app *::before, .mf-app *::after { box-sizing: border-box; }
      .mf-app ::selection { background: var(--blue-soft); }
      .mf-app :focus-visible { outline: none; box-shadow: var(--ring); border-radius: var(--r-xs); }
      .mf-app button { transition: background .16s var(--ease), border-color .16s var(--ease), color .16s var(--ease), box-shadow .16s var(--ease), transform .12s var(--ease); }
      @media (prefers-reduced-motion: reduce) {
        .mf-app *, .mf-app *::before, .mf-app *::after { animation-duration: .001ms !important; transition-duration: .001ms !important; scroll-behavior: auto !important; }
      }

      .mf-topbar {
        border-bottom: 1px solid var(--line); background: rgba(255,255,255,0.86); backdrop-filter: saturate(180%) blur(8px);
        position: sticky; top: 0; z-index: 20;
      }
      .mf-topbar-inner {
        display: flex; align-items: center; justify-content: space-between;
        padding: 13px 20px; gap: 10px; flex-wrap: wrap; max-width: 1240px; margin: 0 auto;
      }
      .mf-topbar-left { display: flex; align-items: center; gap: 10px; }
      .mf-topbar-right { display: flex; align-items: center; gap: 10px; }
      .mf-menu-btn { display: none; background: none; border: none; cursor: pointer; color: var(--ink); padding: 2px; border-radius: var(--r-xs); }
      .mf-wordmark { font-family: 'Space Grotesk', sans-serif; font-weight: 600; font-size: 17px; letter-spacing: -0.01em; }
      .mf-crumb { color: var(--ink-soft); font-size: 14px; font-family: 'IBM Plex Mono', monospace; }
      .mf-org-badge { font-size: 12.5px; color: var(--ink-soft); border: 1px solid var(--line); border-radius: 999px; padding: 3px 11px; }
      .mf-step-count { font-size: 12px; font-weight: 600; color: var(--ink); background: var(--paper); border: 1px solid var(--line); border-radius: 999px; padding: 3px 10px; }
      .mf-step-count-of { color: var(--ink-soft); font-weight: 500; }
      @media (max-width: 560px) { .mf-step-count, .mf-org-badge { display: none; } }

      .mf-progress-track { height: 3px; background: var(--line-soft); overflow: hidden; }
      .mf-progress-fill { height: 100%; background: linear-gradient(90deg, var(--sage), var(--blue)); border-radius: 0 3px 3px 0; transition: width .5s var(--ease); }

      .mf-status-pill { font-size: 11.5px; font-weight: 600; padding: 3px 10px; border-radius: 999px; }
      .mf-status-draft { background: var(--line); color: var(--ink-soft); }
      .mf-status-processing { background: var(--blue-soft); color: var(--blue); }
      .mf-status-awaiting-review { background: var(--amber-soft); color: var(--amber); }
      .mf-status-sent { background: var(--sage-soft); color: var(--sage); }

      .mf-body { display: flex; max-width: 1240px; margin: 0 auto; }

      .mf-sidebar {
        width: 248px; flex-shrink: 0; padding: 22px 16px; border-right: 1px solid var(--line);
        position: sticky; top: 54px; height: calc(100vh - 54px); overflow-y: auto;
      }
      .mf-sidebar-case { background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-md); padding: 13px 14px; margin-bottom: 18px; box-shadow: var(--shadow-xs); }
      .mf-sidebar-case-head { display: flex; align-items: center; gap: 10px; }
      .mf-avatar {
        width: 32px; height: 32px; flex-shrink: 0; border-radius: 50%; background: var(--blue); color: #fff;
        display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700;
        font-family: 'Space Grotesk', sans-serif; letter-spacing: 0.02em;
      }
      .mf-sidebar-case-name { font-family: 'Space Grotesk', sans-serif; font-weight: 600; font-size: 13.5px; margin: 0; line-height: 1.3; }
      .mf-sidebar-case-id { font-family: 'IBM Plex Mono', monospace; font-size: 11px; color: var(--ink-soft); margin: 1px 0 0; }
      .mf-sidebar-case-meta { font-size: 11.5px; color: var(--ink-soft); margin: 10px 0 0; padding-top: 9px; border-top: 1px solid var(--line-soft); }

      .mf-nav-progress { display: flex; justify-content: space-between; font-size: 10.5px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; color: var(--ink-soft); padding: 0 6px 8px; }

      .mf-nav { display: flex; flex-direction: column; }
      .mf-nav-item {
        position: relative; display: flex; align-items: center; gap: 11px; text-align: left; font-family: inherit; font-size: 13.5px;
        padding: 7px 10px; border-radius: var(--r-sm); border: none; background: none; color: var(--ink-soft); cursor: pointer;
        transition: background .16s var(--ease), color .16s var(--ease);
      }
      .mf-nav-item + .mf-nav-item::before {
        content: ""; position: absolute; left: 21px; top: -8px; width: 2px; height: 12px; background: var(--line);
      }
      .mf-nav-item.is-done::before, .mf-nav-item.is-current::before { background: var(--sage); }
      .mf-nav-marker {
        width: 22px; height: 22px; flex-shrink: 0; border-radius: 50%; display: flex; align-items: center; justify-content: center;
        border: 1.5px solid var(--line); background: var(--paper-raised); color: var(--ink-soft); font-size: 11px; font-weight: 700;
        transition: all .16s var(--ease);
      }
      .mf-nav-label { line-height: 1.3; }
      .mf-nav-item:hover:not(:disabled) { background: var(--line-soft); color: var(--ink); }
      .mf-nav-item.is-current { background: var(--blue-soft); color: var(--blue); font-weight: 600; }
      .mf-nav-item.is-current .mf-nav-marker { border-color: var(--blue); color: var(--blue); background: var(--paper-raised); box-shadow: var(--ring); }
      .mf-nav-item.is-done { color: var(--ink); }
      .mf-nav-item.is-done .mf-nav-marker { background: var(--sage); border-color: var(--sage); color: #fff; }
      .mf-nav-item.is-locked { opacity: 0.45; cursor: not-allowed; }
      .mf-sidebar-overlay { display: none; }

      .mf-main { flex: 1; min-width: 0; padding: 32px 40px 90px; }
      .mf-page { max-width: 940px; }
      .mf-page-transition { animation: mf-fade-in 0.3s var(--ease); }
      @keyframes mf-fade-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }

      .mf-page-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; flex-wrap: wrap; }
      .mf-page-title { font-family: 'Space Grotesk', sans-serif; font-size: 25px; font-weight: 600; margin: 0 0 7px; letter-spacing: -0.015em; }
      .mf-page-subhead { color: var(--ink-soft); font-size: 14.5px; margin: 0 0 24px; max-width: 64ch; line-height: 1.6; }

      .mf-toggle-link { display: flex; align-items: center; gap: 6px; background: none; border: none; color: var(--blue); font-size: 13.5px; font-weight: 500; cursor: pointer; padding: 4px 0; white-space: nowrap; }
      .mf-toggle-link:hover { text-decoration: underline; }
      .mf-inline-link { background: none; border: none; padding: 0; font-family: inherit; font-size: 12.5px; font-weight: 500; color: var(--blue); cursor: pointer; }
      .mf-inline-link:hover { text-decoration: underline; }

      .mf-two-col { display: grid; grid-template-columns: 1fr 300px; gap: 28px; align-items: start; }
      @media (max-width: 860px) { .mf-two-col { grid-template-columns: 1fr; } }

      .mf-field { margin-bottom: 22px; }
      .mf-label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; letter-spacing: 0.005em; }
      .mf-label-row { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 4px; }
      .mf-select-wrap { position: relative; max-width: 300px; }
      .mf-select, .mf-input, .mf-textarea {
        width: 100%; font-family: inherit; font-size: 14px; border: 1px solid var(--line); border-radius: var(--r-sm);
        background: var(--paper-raised); color: var(--ink); transition: border-color .16s var(--ease), box-shadow .16s var(--ease);
      }
      .mf-select { appearance: none; padding: 9px 32px 9px 12px; cursor: pointer; }
      .mf-input { padding: 9px 12px; }
      .mf-textarea { min-height: 170px; line-height: 1.55; padding: 12px; resize: vertical; }
      .mf-select:hover, .mf-input:hover, .mf-textarea:hover { border-color: #C3CBD0; }
      .mf-select:focus, .mf-input:focus, .mf-textarea:focus { outline: none; border-color: var(--blue); box-shadow: var(--ring); }
      .mf-select-icon { position: absolute; right: 11px; top: 50%; transform: translateY(-50%); pointer-events: none; color: var(--ink-soft); }
      .mf-input-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
      @media (max-width: 620px) { .mf-input-grid { grid-template-columns: 1fr; } }
      .mf-error { font-size: 12.5px; color: var(--clay); margin-top: 6px; display: flex; align-items: center; gap: 5px; }
      .mf-error::before { content: "⚠"; font-size: 11px; }

      .mf-checklist { border: 1px solid var(--line); border-radius: var(--r-sm); background: var(--paper-raised); padding: 10px 13px; margin-bottom: 10px; box-shadow: var(--shadow-xs); }
      .mf-checklist-title { font-size: 12px; color: var(--ink-soft); margin: 0 0 6px; }
      .mf-checklist-row { display: flex; align-items: center; gap: 8px; font-size: 13px; padding: 3px 0; color: var(--ink-soft); }
      .mf-checklist-dot { width: 15px; height: 15px; border-radius: 50%; border: 1.5px solid var(--line); display: flex; align-items: center; justify-content: center; color: white; flex-shrink: 0; }
      .mf-checklist-dot.met { background: var(--sage); border-color: var(--sage); }
      .mf-checklist-met { color: var(--ink); }

      .mf-dropzone { border: 1.5px dashed #C6CED3; border-radius: var(--r-md); background: var(--paper-raised); padding: 24px 20px; text-align: center; cursor: pointer; transition: border-color .16s var(--ease), background .16s var(--ease); }
      .mf-dropzone:hover { border-color: var(--blue); background: var(--blue-soft); }
      .mf-dropzone.drag { border-color: var(--blue); background: var(--blue-soft); }
      .mf-dropzone-title { font-size: 13.5px; font-weight: 600; margin-top: 6px; }
      .mf-dropzone-sub { font-size: 12.5px; color: var(--ink-soft); }
      .mf-filelist { margin-top: 10px; display: flex; flex-direction: column; gap: 5px; }
      .mf-file { display: flex; align-items: center; gap: 8px; font-size: 13px; border: 1px solid var(--line); border-radius: var(--r-xs); padding: 8px 10px; background: var(--paper-raised); box-shadow: var(--shadow-xs); }
      .mf-file-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .mf-file-remove { background: none; border: none; cursor: pointer; color: var(--ink-soft); display: flex; }
      .mf-file-remove:hover { color: var(--clay); }

      .mf-summary-card { background: var(--paper-raised); border: 1px solid var(--line); border-top: 3px solid var(--blue); border-radius: var(--r-md); padding: 18px 20px; position: sticky; top: 78px; box-shadow: var(--shadow-md); }
      .mf-summary-title { font-family: 'Space Grotesk', sans-serif; font-size: 14.5px; font-weight: 600; margin: 0 0 12px; }
      .mf-summary-row { display: flex; justify-content: space-between; gap: 10px; font-size: 13px; padding: 8px 0; border-bottom: 1px solid var(--line-soft); }
      .mf-summary-row:last-of-type { border-bottom: none; }
      .mf-summary-key { color: var(--ink-soft); }
      .mf-summary-val { font-weight: 500; text-align: right; }
      .mf-tiny-note { font-size: 11.5px; color: var(--ink-soft); text-align: center; margin-top: 10px; line-height: 1.5; }

      .mf-status-pill-sm { font-size: 11px; font-weight: 500; padding: 2px 9px; border-radius: 999px; }
      .mf-status-pill-amber { background: var(--amber-soft); color: var(--amber); }
      .mf-status-pill-sage { background: var(--sage-soft); color: var(--sage); }
      .mf-status-pill-clay { background: var(--clay-soft); color: var(--clay); }

      .mf-primary-btn, .mf-ghost-btn, .mf-send-btn {
        font-family: inherit; font-size: 14px; font-weight: 600; padding: 10px 17px; border-radius: var(--r-sm); cursor: pointer;
        display: flex; align-items: center; justify-content: center; gap: 7px;
      }
      .mf-primary-btn { background: var(--blue); border: 1px solid var(--blue); color: white; box-shadow: var(--shadow-sm); }
      .mf-primary-btn:hover:not(:disabled) { background: var(--blue-dark); border-color: var(--blue-dark); box-shadow: var(--shadow-md); transform: translateY(-1px); }
      .mf-primary-btn:active:not(:disabled) { transform: translateY(0); box-shadow: var(--shadow-xs); }
      .mf-primary-btn:disabled { background: var(--line); border-color: var(--line); color: var(--ink-soft); cursor: not-allowed; box-shadow: none; }
      .mf-primary-btn.full { width: 100%; margin-top: 14px; }
      .mf-ghost-btn { background: var(--paper-raised); border: 1px solid var(--line); color: var(--ink); }
      .mf-ghost-btn:hover { border-color: var(--blue); color: var(--blue); background: var(--blue-soft); }
      .mf-ghost-btn:active { transform: translateY(1px); }
      .mf-send-btn { width: 100%; background: var(--blue); border: 1px solid var(--blue); color: white; font-size: 14.5px; padding: 12px 14px; margin: 18px 0 4px; box-shadow: var(--shadow-sm); }
      .mf-send-btn:hover:not(:disabled) { background: var(--blue-dark); border-color: var(--blue-dark); box-shadow: var(--shadow-md); transform: translateY(-1px); }
      .mf-send-btn:active:not(:disabled) { transform: translateY(0); }
      .mf-send-btn:disabled { background: var(--line); border-color: var(--line); color: var(--ink-soft); cursor: not-allowed; box-shadow: none; }

      .mf-page-nav { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid var(--line); }

      .mf-info-strip { display: flex; gap: 9px; align-items: flex-start; background: var(--blue-soft); border: 1px solid #CFE0E7; border-radius: var(--r-sm); padding: 12px 14px; margin: 18px 0; font-size: 12.5px; color: var(--blue-dark); line-height: 1.55; }
      .mf-ai-banner { display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap; background: var(--blue-soft); border: 1px solid #CFE0E7; border-radius: var(--r-sm); padding: 10px 14px; margin: 0 0 18px; font-size: 12.5px; color: var(--blue-dark); }
      .mf-ai-tag { display: inline-flex; align-items: center; gap: 3px; font-size: 10px; font-weight: 700; letter-spacing: .02em; color: var(--blue); background: var(--blue-soft); border: 1px solid rgba(29,92,122,.25); border-radius: 999px; padding: 1px 6px; margin-left: 6px; vertical-align: 1px; white-space: nowrap; }
      .mf-note-box { background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-sm); padding: 14px 16px; margin-bottom: 20px; box-shadow: var(--shadow-xs); }
      .mf-note-box-title { font-size: 12px; font-weight: 600; color: var(--ink-soft); margin: 0 0 8px; }
      .mf-mono-block { font-family: 'IBM Plex Mono', monospace; font-size: 12.5px; line-height: 1.6; color: var(--ink-soft); white-space: pre-wrap; margin: 0; }

      .mf-field-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 6px; }
      @media (max-width: 620px) { .mf-field-grid { grid-template-columns: 1fr; } }
      .mf-field-card { background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-sm); padding: 13px 15px; box-shadow: var(--shadow-xs); transition: box-shadow .16s var(--ease), border-color .16s var(--ease); }
      .mf-field-card:hover { box-shadow: var(--shadow-sm); border-color: #C7CFD4; }
      .mf-field-card.null { border-style: dashed; box-shadow: none; background: transparent; }
      .mf-field-key { font-size: 12px; font-weight: 600; color: var(--ink-soft); margin: 0 0 5px; }
      .mf-field-value { font-size: 14px; margin: 0 0 6px; line-height: 1.45; }
      .mf-evidence { display: block; font-family: 'IBM Plex Mono', monospace; font-size: 11.5px; color: var(--blue); }
      .mf-null { font-size: 13.5px; color: var(--ink-soft); font-style: italic; }

      .mf-tabs { display: flex; gap: 18px; margin-bottom: 12px; border-bottom: 1px solid var(--line); }
      .mf-tab { font-family: inherit; font-size: 13.5px; font-weight: 500; padding: 8px 0; background: none; border: none; border-bottom: 2px solid transparent; color: var(--ink-soft); cursor: pointer; }
      .mf-tab.active { color: var(--ink); border-bottom-color: var(--blue); font-weight: 600; }
      .mf-code-panel { background: #101826; border-radius: var(--r-md); padding: 16px 18px; overflow-x: auto; margin-bottom: 6px; box-shadow: var(--shadow-md); }
      .mf-code-panel pre { margin: 0; font-family: 'IBM Plex Mono', monospace; font-size: 12.5px; line-height: 1.7; color: #C9D3DF; }
      .mf-json-key { color: #7FB0C9; } .mf-json-string { color: #A7C980; } .mf-json-number { color: #E0A468; } .mf-json-boolean { color: #C99BE0; } .mf-json-null { color: #7A879C; font-style: italic; }
      .mf-table-wrap { background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-md); overflow: hidden; margin-bottom: 6px; box-shadow: var(--shadow-sm); }
      .mf-table { width: 100%; border-collapse: collapse; font-size: 13px; }
      .mf-table th { text-align: left; font-size: 10.5px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; color: var(--ink-soft); padding: 10px 14px; border-bottom: 1px solid var(--line); background: var(--paper); }
      .mf-table td { padding: 10px 14px; border-bottom: 1px solid var(--line-soft); }
      .mf-table tr:last-child td { border-bottom: none; }
      .mf-table tbody tr { transition: background .12s var(--ease); }
      .mf-table tbody tr:hover { background: var(--line-soft); }
      .mf-path { font-family: 'IBM Plex Mono', monospace; font-size: 12px; }
      .muted-row td { color: var(--ink-soft); }
      .mf-type-badge { font-size: 11px; padding: 2px 8px; border-radius: 999px; }
      .mf-type-blue { background: var(--blue-soft); color: var(--blue); }
      .mf-type-amber { background: var(--amber-soft); color: var(--amber); }
      .mf-type-sage { background: var(--sage-soft); color: var(--sage); }
      .mf-type-muted { background: var(--paper); color: var(--ink-soft); border: 1px dashed var(--line); }
      .mf-tab { display: inline-flex; align-items: center; gap: 6px; }
      .mf-tab-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--amber); }

      .mf-fields-view { margin-bottom: 6px; }
      .mf-fields-list-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
      .mf-fields-item-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid var(--line-soft); }
      .mf-fields-item-label { font-size: 12px; font-weight: 600; color: var(--ink-soft); letter-spacing: 0.02em; }
      .mf-fields-view .mf-field { margin-bottom: 14px; }
      .mf-fields-view .mf-field:last-child { margin-bottom: 0; }
      .mf-mini-btn { display: inline-flex; align-items: center; gap: 5px; font-family: inherit; font-size: 12px; font-weight: 500; padding: 5px 10px; border-radius: var(--r-xs); border: 1px solid var(--line); background: var(--paper-raised); color: var(--blue); cursor: pointer; }
      .mf-mini-btn:hover { border-color: var(--blue); background: var(--blue-soft); }
      .mf-mini-btn.ghost { color: var(--ink-soft); }
      .mf-mini-btn.ghost:hover { color: var(--clay); border-color: var(--clay); background: var(--clay-soft); }

      .mf-auth-screen { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; }
      .mf-auth-card { width: 100%; max-width: 380px; background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-lg); padding: 28px 26px 24px; box-shadow: var(--shadow-lg); }
      .mf-auth-brand { display: flex; align-items: center; gap: 8px; margin-bottom: 18px; }
      .mf-auth-title { font-family: 'Space Grotesk', sans-serif; font-size: 21px; font-weight: 600; margin: 0 0 6px; letter-spacing: -0.015em; }

      .mf-section-label { font-size: 13.5px; font-weight: 600; color: var(--ink-soft); margin: 22px 0 10px; }
      .mf-card { background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-md); padding: 17px 19px; margin-bottom: 8px; box-shadow: var(--shadow-sm); }
      .mf-rule-row { display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; border-bottom: 1px solid var(--line); font-size: 13.5px; }
      .mf-rule-row:last-child { border-bottom: none; }
      .mf-rule-dot { width: 17px; height: 17px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px; color: white; }
      .mf-rule-dot.pass { background: var(--sage); } .mf-rule-dot.fail { background: var(--amber); }
      .mf-rule-detail { display: block; font-size: 12px; color: var(--ink-soft); margin-top: 1px; }
      .mf-verdict { margin-top: 12px; padding: 12px 14px; border-radius: 4px; font-size: 13.5px; display: flex; gap: 9px; align-items: flex-start; }
      .mf-verdict-gap { background: var(--amber-soft); color: var(--amber); }
      .mf-verdict-clean { background: var(--sage-soft); color: var(--sage); }

      .mf-trace-row { display: flex; align-items: center; gap: 10px; padding: 7px 0; border-bottom: 1px solid var(--line); font-family: 'IBM Plex Mono', monospace; font-size: 12px; color: var(--ink-soft); }
      .mf-trace-row.matched { color: var(--ink); font-weight: 500; }
      .mf-trace-mark { width: 14px; text-align: center; }
      .mf-priority-result { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; padding-top: 10px; border-top: 1px solid var(--line); }
      .mf-priority-select { font-family: inherit; font-size: 13px; padding: 5px 10px; border: 1px solid var(--line); border-radius: 4px; background: var(--paper); cursor: pointer; }
      .mf-specialist-list { margin-top: 10px; display: flex; flex-direction: column; gap: 7px; }
      .mf-specialist-item { display: flex; justify-content: space-between; align-items: center; border: 1px solid var(--line); border-radius: 4px; padding: 9px 12px; font-size: 13px; }
      .mf-specialist-name { font-weight: 600; }
      .mf-specialist-meta { font-size: 11.5px; color: var(--ink-soft); }
      .mf-match-chip { font-size: 11px; color: var(--blue); background: var(--blue-soft); padding: 2px 8px; border-radius: 999px; }

      .mf-meta-row { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 16px; }
      .mf-meta-pill { font-size: 12px; color: var(--ink-soft); border: 1px solid var(--line); border-radius: 999px; padding: 4px 11px; background: var(--paper-raised); }
      .mf-meta-pill b { color: var(--ink); }
      .mf-trace-box { background: var(--paper-raised); border: 1px solid var(--line); border-radius: 4px; padding: 12px 14px; margin-bottom: 16px; }
      .mf-trace-item { display: flex; justify-content: space-between; font-size: 12.5px; padding: 5px 0; border-bottom: 1px solid var(--line); }
      .mf-trace-item:last-child { border-bottom: none; }
      .mf-trace-field { font-family: 'IBM Plex Mono', monospace; color: var(--blue); }
      .mf-toolbar { display: flex; gap: 8px; margin-bottom: 10px; }
      .mf-tool-btn { display: flex; align-items: center; gap: 6px; font-family: inherit; font-size: 12.5px; font-weight: 500; padding: 6px 11px; border-radius: 4px; border: 1px solid var(--line); background: var(--paper-raised); cursor: pointer; }
      .mf-tool-btn:hover { border-color: var(--blue); color: var(--blue); }

      .mf-letter { background: var(--paper-raised); border: 1px solid var(--line); border-top: 3px solid var(--blue); border-radius: var(--r-md); padding: 24px; margin-bottom: 16px; box-shadow: var(--shadow-md); }
      .mf-letter-org { font-family: 'Space Grotesk', sans-serif; font-weight: 600; font-size: 15px; }
      .mf-letter-date { font-size: 12px; color: var(--ink-soft); margin-bottom: 14px; }
      .mf-letter-body { font-size: 13.5px; line-height: 1.65; white-space: pre-wrap; }
      .mf-letter-attach { display: flex; align-items: center; gap: 7px; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--line); font-size: 12.5px; color: var(--ink-soft); }
      .mf-edit-textarea { width: 100%; min-height: 200px; font-family: inherit; font-size: 13.5px; line-height: 1.6; padding: 11px; border: 1px solid var(--blue); border-radius: 4px; background: var(--paper); resize: vertical; }

      .mf-accordion { background: var(--paper-raised); border: 1px solid var(--line); border-radius: var(--r-sm); margin-bottom: 8px; overflow: hidden; box-shadow: var(--shadow-xs); }
      .mf-accordion-head { width: 100%; display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; background: none; border: none; cursor: pointer; font-family: inherit; transition: background .14s var(--ease); }
      .mf-accordion-head:hover { background: var(--line-soft); }
      .mf-accordion-title { font-size: 13.5px; font-weight: 600; display: flex; align-items: center; gap: 10px; }
      .mf-accordion-badge { font-size: 11px; font-weight: 500; padding: 2px 8px; border-radius: 999px; }
      .mf-tone-sage { background: var(--sage-soft); color: var(--sage); }
      .mf-tone-amber { background: var(--amber-soft); color: var(--amber); }
      .mf-accordion-body { padding: 0 15px 12px; font-size: 12.5px; color: var(--ink-soft); line-height: 1.6; border-top: 1px solid var(--line); padding-top: 10px; }
      .mf-accordion-body ul { margin: 0; padding-left: 18px; }

      .mf-specialist-wrap { position: relative; margin-bottom: 12px; }
      .mf-specialist-trigger { width: 100%; display: flex; justify-content: space-between; align-items: center; font-family: inherit; font-size: 13.5px; padding: 10px 12px; border: 1px solid var(--line); border-radius: 4px; background: var(--paper-raised); cursor: pointer; text-align: left; }
      .mf-specialist-trigger.placeholder { color: var(--ink-soft); }
      .mf-specialist-menu { position: absolute; top: calc(100% + 4px); left: 0; right: 0; z-index: 5; background: var(--paper-raised); border: 1px solid var(--line); border-radius: 4px; box-shadow: 0 6px 16px rgba(20,33,61,0.08); overflow: hidden; }
      .mf-specialist-option { width: 100%; text-align: left; padding: 10px 12px; background: none; border: none; cursor: pointer; border-bottom: 1px solid var(--line); font-size: 13px; }
      .mf-specialist-option:last-child { border-bottom: none; }
      .mf-specialist-option:hover { background: var(--blue-soft); }

      .mf-channel-row { display: flex; gap: 8px; margin-bottom: 16px; }
      .mf-channel-btn { flex: 1; font-family: inherit; font-size: 12.5px; padding: 8px; border-radius: 4px; border: 1px solid var(--line); background: var(--paper-raised); color: var(--ink-soft); cursor: pointer; }
      .mf-channel-btn.active { border-color: var(--blue); color: var(--blue); background: var(--blue-soft); font-weight: 600; }

      .mf-attest-box { background: var(--paper-raised); border: 1px solid var(--line); border-radius: 4px; padding: 14px 16px; margin-bottom: 12px; }
      .mf-attest-row { display: flex; align-items: flex-start; gap: 9px; font-size: 13px; padding: 5px 0; }
      .mf-attest-row input { margin-top: 3px; }
      .mf-attest-row.gap { color: var(--amber); }

      .mf-sent-card { background: var(--paper-raised); border: 1px solid var(--line); border-top: 3px solid var(--sage); border-radius: var(--r-lg); padding: 28px; max-width: 520px; box-shadow: var(--shadow-lg); }
      .mf-sent-icon { width: 40px; height: 40px; border-radius: 50%; background: var(--sage-soft); color: var(--sage); display: flex; align-items: center; justify-content: center; margin-bottom: 16px; }
      .mf-sent-title { font-family: 'Space Grotesk', sans-serif; font-size: 18px; font-weight: 600; margin: 0 0 6px; }
      .mf-sent-body { font-size: 13.5px; color: var(--ink-soft); line-height: 1.55; margin: 0 0 16px; }
      .mf-sent-meta { font-size: 12.5px; color: var(--ink-soft); border-top: 1px solid var(--line); padding-top: 12px; }
      .mf-sent-meta div { display: flex; justify-content: space-between; padding: 3px 0; }

      .mf-toast {
        position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
        background: var(--ink); color: white; font-size: 13.5px; padding: 12px 18px; border-radius: 999px;
        display: flex; align-items: center; gap: 8px; box-shadow: var(--shadow-lg); z-index: 50;
        animation: mf-toast-in 0.24s var(--ease);
      }
      @keyframes mf-toast-in { from { opacity: 0; transform: translate(-50%, 8px); } to { opacity: 1; transform: translate(-50%, 0); } }

      @keyframes mf-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      .mf-spin { animation: mf-spin 0.8s linear infinite; }

      @media (max-width: 860px) {
        .mf-menu-btn { display: flex; }
        .mf-sidebar {
          position: fixed; left: -280px; top: 54px; bottom: 0; width: 262px; background: var(--paper);
          transition: left 0.24s var(--ease); z-index: 40; box-shadow: var(--shadow-lg);
        }
        .mf-sidebar.open { left: 0; }
        .mf-sidebar-overlay { display: block; position: fixed; inset: 54px 0 0 0; background: rgba(20,33,61,0.28); z-index: 30; animation: mf-fade-in .2s var(--ease); }
        .mf-main { padding: 22px 18px 70px; }
      }

      /* ── AI-contract additions (extraction grounding, pathway signal, feedback) ── */
      .mf-provenance { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:16px; }
      .mf-prov-pill { font-size:11.5px; padding:4px 9px; border-radius:999px; background:var(--paper-raised);
        border:1px solid var(--line); color:var(--ink-soft); }
      .mf-prov-pill b { color:var(--ink); font-weight:600; }

      .mf-principle-banner { display:flex; gap:11px; align-items:flex-start; padding:13px 15px; border-radius:var(--r-md);
        background:linear-gradient(180deg,var(--blue-soft),#fff); border:1px solid var(--line); margin-bottom:20px;
        font-size:13px; color:var(--ink); line-height:1.5; }
      .mf-principle-banner b { font-weight:600; }

      .mf-section-list { display:flex; flex-direction:column; gap:1px; }
      .mf-section-item { padding:12px 14px; background:var(--paper-raised); border:1px solid var(--line-soft); }
      .mf-section-item:first-child { border-top-left-radius:var(--r-md); border-top-right-radius:var(--r-md); }
      .mf-section-item:last-child { border-bottom-left-radius:var(--r-md); border-bottom-right-radius:var(--r-md); }
      .mf-section-item + .mf-section-item { border-top:none; }
      .mf-section-title { font-size:11px; letter-spacing:.06em; text-transform:uppercase; color:var(--ink-soft); font-weight:600; }
      .mf-section-content { font-size:13.5px; color:var(--ink); margin-top:3px; line-height:1.45; }
      .mf-verbatim-chip { display:inline-flex; align-items:center; gap:5px; margin-top:7px; font-size:11.5px;
        font-family:'IBM Plex Mono',monospace; padding:3px 8px; border-radius:var(--r-xs);
        background:var(--sage-soft); color:var(--sage); border:1px solid rgba(79,124,108,.25); }
      .mf-verbatim-chip.unverified { background:var(--clay-soft); color:var(--clay); border-color:rgba(168,67,59,.25); }

      .mf-grounded-item { display:flex; gap:10px; align-items:flex-start; padding:9px 12px; background:var(--paper-raised);
        border:1px solid var(--line-soft); border-radius:var(--r-sm); }
      .mf-grounded-item + .mf-grounded-item { margin-top:6px; }
      .mf-grounded-label { font-size:11px; letter-spacing:.04em; text-transform:uppercase; color:var(--blue);
        font-weight:600; min-width:120px; flex-shrink:0; padding-top:1px; }
      .mf-grounded-phrase { font-size:12.5px; font-family:'IBM Plex Mono',monospace; color:var(--ink); line-height:1.4; }

      .mf-urgency { display:inline-flex; align-items:center; gap:6px; font-size:12px; font-weight:600;
        padding:4px 11px; border-radius:999px; text-transform:uppercase; letter-spacing:.04em; }
      .mf-urgency-routine { background:var(--sage-soft); color:var(--sage); }
      .mf-urgency-review { background:var(--amber-soft); color:var(--amber); }
      .mf-urgency-urgent { background:var(--clay-soft); color:var(--clay); }

      .mf-criterion-row { display:flex; gap:10px; align-items:flex-start; padding:10px 0; border-bottom:1px solid var(--line-soft); }
      .mf-criterion-row:last-child { border-bottom:none; }
      .mf-criterion-mark { width:18px; height:18px; border-radius:5px; flex-shrink:0; display:grid; place-items:center;
        font-size:11px; font-weight:700; }
      .mf-criterion-mark.met { background:var(--sage-soft); color:var(--sage); }
      .mf-criterion-mark.missing { background:var(--clay-soft); color:var(--clay); }
      .mf-criterion-mark.optional { background:var(--line-soft); color:var(--ink-soft); }
      .mf-criterion-body { flex:1; font-size:13px; }
      .mf-criterion-label { color:var(--ink); }
      .mf-criterion-req { font-size:11px; color:var(--ink-soft); margin-left:6px; }
      .mf-criterion-ev { display:block; font-size:11.5px; font-family:'IBM Plex Mono',monospace; color:var(--sage); margin-top:3px; }

      .mf-redflag-row { display:flex; gap:9px; align-items:center; padding:8px 0; font-size:12.5px; color:var(--ink-soft); }
      .mf-redflag-hit { color:var(--clay); font-weight:600; }

      .mf-choice-row { display:flex; gap:10px; flex-wrap:wrap; margin:6px 0 4px; }
      .mf-choice { flex:1; min-width:150px; text-align:left; padding:12px 14px; border-radius:var(--r-sm);
        border:1.5px solid var(--line); background:var(--paper-raised); cursor:pointer; transition:all .12s var(--ease); }
      .mf-choice:hover { border-color:var(--blue); }
      .mf-choice.active { border-color:var(--blue); background:var(--blue-soft); box-shadow:var(--ring); }
      .mf-choice-title { font-size:13px; font-weight:600; color:var(--ink); }
      .mf-choice-sub { font-size:11.5px; color:var(--ink-soft); margin-top:2px; }

      .mf-feedback-diff { font-size:12.5px; font-family:'IBM Plex Mono',monospace; line-height:1.55; white-space:pre-wrap;
        background:var(--paper); border:1px solid var(--line-soft); border-radius:var(--r-sm); padding:12px 14px; }
      .mf-feedback-diff .add { color:var(--sage); }
      .mf-feedback-diff .del { color:var(--clay); text-decoration:line-through; }
    `}</style>
  );
}
